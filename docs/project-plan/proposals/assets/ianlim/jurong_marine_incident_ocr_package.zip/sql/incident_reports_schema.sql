-- Run AFTER selecting the existing Jurong Marine database (USE <your_db>;).
-- Non-destructive: no ALTER/UPDATE on the supplied safety_incidents table.
-- MySQL 8.0+; existing safety_incidents is expected to have:
-- incident_id, incident_date, machine_id, description, severity,
-- lost_days, emp_code, reporting.

CREATE TABLE IF NOT EXISTS incident_report_ocr (
    report_no VARCHAR(32) NOT NULL PRIMARY KEY,
    incident_id INT NULL,
    incident_date DATE NULL,
    machine_id VARCHAR(80) NULL,
    location_raw VARCHAR(255) NULL,
    emp_code VARCHAR(32) NULL,
    description TEXT NULL,
    severity_raw TINYINT UNSIGNED NULL,
    severity_scale ENUM('OLD_1_WORST','NEW_5_WORST','UNKNOWN') NOT NULL DEFAULT 'UNKNOWN',
    scale_source ENUM('FORM_LABEL','DATE_INFERRED','UNDETERMINED') NOT NULL DEFAULT 'UNDETERMINED',
    severity_5_worst TINYINT UNSIGNED NULL,
    lost_days SMALLINT UNSIGNED NULL,
    reporting VARCHAR(255) NULL,
    immediate_action TEXT NULL,
    root_cause_reference VARCHAR(255) NULL,
    image_path VARCHAR(1024) NOT NULL,
    image_sha256 CHAR(64) NOT NULL,
    ocr_confidence DECIMAL(5,2) NULL,
    extraction_flags JSON NOT NULL,
    ocr_raw_json JSON NOT NULL,
    review_status ENUM('PENDING_REVIEW','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING_REVIEW',
    reviewed_by VARCHAR(100) NULL,
    reviewed_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_ocr_incident_id (incident_id),
    KEY ix_ocr_incident_date (incident_date),
    CONSTRAINT ck_ocr_severity_raw CHECK (severity_raw IS NULL OR severity_raw BETWEEN 1 AND 5),
    CONSTRAINT ck_ocr_severity_std CHECK (severity_5_worst IS NULL OR severity_5_worst BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Raw DB scores are mixed across the July 2025 transition. Normalise to:
-- 5 = MOST SEVERE. July 2025 scores MUST have an APPROVED source form
-- that explicitly shows the original scale; otherwise return NULL.
CREATE OR REPLACE VIEW vw_safety_incidents_normalized AS
SELECT
    s.incident_id,
    s.incident_date,
    s.machine_id,
    s.description,
    s.severity AS severity_raw_database,
    s.lost_days,
    s.emp_code,
    s.reporting,
    CASE
      WHEN s.incident_date < '2025-07-01' THEN 'OLD_1_WORST'
      WHEN s.incident_date >= '2025-08-01' THEN 'NEW_5_WORST'
      WHEN o.review_status = 'APPROVED' AND o.scale_source = 'FORM_LABEL'
           AND o.severity_raw = s.severity
           AND o.severity_scale IN ('OLD_1_WORST', 'NEW_5_WORST')
        THEN o.severity_scale
      ELSE 'UNKNOWN_JULY_2025'
    END AS effective_severity_scale,
    CASE
      WHEN s.severity NOT BETWEEN 1 AND 5 THEN NULL
      WHEN s.incident_date < '2025-07-01' THEN 6 - s.severity
      WHEN s.incident_date >= '2025-08-01' THEN s.severity
      WHEN o.review_status = 'APPROVED' AND o.scale_source = 'FORM_LABEL'
           AND o.severity_raw = s.severity
           AND o.severity_scale = 'OLD_1_WORST' THEN 6 - s.severity
      WHEN o.review_status = 'APPROVED' AND o.scale_source = 'FORM_LABEL'
           AND o.severity_raw = s.severity
           AND o.severity_scale = 'NEW_5_WORST' THEN s.severity
      ELSE NULL
    END AS severity_5_worst,
    CASE
      WHEN s.incident_date >= '2025-07-01' AND s.incident_date < '2025-08-01'
           AND NOT (o.review_status = 'APPROVED' AND o.scale_source = 'FORM_LABEL'
                    AND o.severity_raw = s.severity
                    AND o.severity_scale <> 'UNKNOWN')
        THEN 'REVIEW_JULY_CUTOVER'
      ELSE 'SCALE_RESOLVED'
    END AS severity_audit_status
FROM safety_incidents AS s
LEFT JOIN incident_report_ocr AS o
       ON s.incident_id = o.incident_id
      AND s.incident_date = o.incident_date;

-- Differences between the photographed forms and the legacy table.
-- This view compares RAW values and NEVER applies severity normalisation first.
CREATE OR REPLACE VIEW vw_incident_ocr_reconciliation AS
SELECT
    o.report_no,
    o.incident_id,
    o.incident_date AS image_incident_date,
    s.incident_date AS database_incident_date,
    o.severity_raw AS image_severity_raw,
    s.severity AS database_severity_raw,
    o.severity_scale,
    o.severity_5_worst AS image_severity_5_worst,
    o.review_status,
    o.ocr_confidence,
    o.image_sha256,
    CASE WHEN s.incident_id IS NULL THEN 'NOT_IN_SAFETY_INCIDENTS'
         ELSE COALESCE(NULLIF(CONCAT_WS(';',
            IF(NOT (o.incident_date <=> s.incident_date), 'DATE_MISMATCH', NULL),
            IF(NOT (o.machine_id <=> s.machine_id), 'MACHINE_MISMATCH', NULL),
            IF(NOT (o.emp_code <=> s.emp_code), 'EMPLOYEE_MISMATCH', NULL),
            IF(NOT (o.severity_raw <=> s.severity), 'RAW_SEVERITY_MISMATCH', NULL),
            IF(NOT (o.lost_days <=> s.lost_days), 'LOST_DAYS_MISMATCH', NULL),
            IF(NOT (o.description <=> s.description), 'DESCRIPTION_MISMATCH', NULL),
            IF(NOT (o.reporting <=> s.reporting), 'REPORTING_MISMATCH', NULL)
         ), ''), 'MATCH') END AS reconciliation_result,
    o.extraction_flags
FROM incident_report_ocr AS o
LEFT JOIN safety_incidents AS s ON o.incident_id = s.incident_id;

-- Helpful audit queries (run after ingest):
-- SELECT * FROM vw_incident_ocr_reconciliation WHERE reconciliation_result <> 'MATCH';
-- SELECT * FROM vw_safety_incidents_normalized WHERE severity_5_worst IS NULL;
-- SELECT incident_id, incident_date, severity_raw_database,
--        effective_severity_scale, severity_5_worst
-- FROM vw_safety_incidents_normalized
-- WHERE incident_id IN (900, 906, 907, 911, 912, 924)
-- ORDER BY incident_id;
--
-- APPROVE ONLY after visual/source verification, e.g.:
-- UPDATE incident_report_ocr SET review_status='APPROVED',
--        reviewed_by='auditor_name', reviewed_at=NOW()
-- WHERE report_no='IR-2025-906'
--   AND incident_date='2025-07-11'
--   AND severity_raw=3
--   AND severity_scale='NEW_5_WORST'
--   AND scale_source='FORM_LABEL';
